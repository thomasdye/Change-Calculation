// Creating Variable
var quarters: Int = 0
var dimes: Int = 0
var nickels: Int = 0
var pennies: Int = 0

// Set change's value
var change: Int = 13

// Set originalChange equal to change to use later
let originalChange = change
var quarterText = ""
var dimeText = ""
var nickelText = ""
var pennyText = ""


// Change Calculation Logic

if change > 0 {
    
    while change > 24 {
        change = change - 25
        quarters += 1
    }
    while change > 9 {
        change = change - 10
        dimes += 1
    }
    while change > 4 {
        change = change - 5
        nickels += 1
    }
    pennies = change
}


// Custom Text Logic
if quarters == 1 {
    quarterText = "Quarter"
} else {
    quarterText = "Quarters"
}

if dimes == 1 {
    dimeText = "Dime"
} else {
    dimeText = "Dimes"
}

if nickels == 1 {
    nickelText = "Nickel"
} else {
    nickelText = "Nickels"
}

if pennies == 1 {
    pennyText = "Penny"
} else {
    pennyText = "Pennies"
}

print("Total Change was $0.\(originalChange)\r----------------------\r\(quarters) \(quarterText)\r\(dimes) \(dimeText)\r\(nickels) \(nickelText)\r\(pennies) \(pennyText)")
